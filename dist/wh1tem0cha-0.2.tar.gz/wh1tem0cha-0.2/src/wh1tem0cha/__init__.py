try:
    from .wh1tem0cha import Wh1teM0cha
except ImportError():
    exit()